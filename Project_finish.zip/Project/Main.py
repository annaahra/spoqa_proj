#-*- coding:utf-8 -*-
from flask import Flask,render_template,session,redirect,request,flash,url_for
from sqlalchemy import not_,or_
from Model import User1
from Model import Board
from Model import Friend
from Model import db
import md5

app = Flask(__name__)
app.secret_key = 'A0Zr98j/3yX R~XHH!jmN]LWX/,?RT'

@app.route('/',methods=['POST','GET'])
def index():
    if 'email' in session:
        
        query = db.session.query(Friend.friend_email).filter(Friend.email == session['email'])
        possible_list = db.session.query(User1.email).filter(not_(User1.email.in_(query)),User1.email != session['email']) # 친구 추가 가능 목록
        
        friend_list = db.session.query(Friend.friend_email).filter(Friend.email == session['email']) # 친구 목록
        
        post_list = db.session.query(Board).filter(or_(Board.email == session['email'],Board.email.in_(query)))
        
        print post_list
        
        #friendid_list.all() # 모든 아이디 출력
        return render_template('index.html',login_id = session['email'],possible_list = possible_list.all(),post_list = post_list,friend_list = friend_list.all())
    
    else:
        return render_template('login.html')

@app.route('/friend_add',methods=['POST','GET'])
def friend_add():
    friend_list = request.form.getlist('friend') # checkbox에서 여러개의 값 가져오기
    
    for friend in friend_list: # 친구 추가한 아이디
        friend_add = Friend(session['email'],friend) # friend DB에 친구를 추가한다.
        db.session.add(friend_add)
        db.session.commit()
           
    return redirect(url_for('index'))

@app.route('/board',methods=['POST','GET']) # post 글 올리기
def board():
    if not session['email'] or not request.values['content']: # 로그인을 하고 내용이 들어왔을때
        flash('잘못된 접근입니다.')
        return redirect(url_for('index'))

    else:
        post = Board(session['email'],request.values['content'])
        db.session.add(post)
        db.session.commit()
        
        return redirect(url_for('index'))        

@app.route('/logout',methods=['POST','GET'])
def logout():
    if 'email' in session:
        session.pop('email',None)
        flash('로그아웃 되었습니다.')
        return redirect(url_for('index'))
    
    else:
        flash('로그인 되어 있는 아이디가 없습니다.')
        return redirect(url_for('index'))

@app.route('/check',methods=['POST','GET'])
def check():
    if not request.values['email'] or not request.values['passwd']: # id하고 패스워드를 제대로 입력하지 않았을때
        return redirect(url_for('index'))
    
    else:
        email = request.values['email']
        passwd = md5.md5(request.values['passwd']).hexdigest() # 패스워드 해쉬값
        
        result = User1.query.filter_by(email = email,passwd = passwd).first()
        
        if result:
            session['email'] = email
            return redirect(url_for('index'))
        else:
            flash('아이디나 패스워드를 확인하여 주세요.')
            return redirect(url_for('index'))
            
@app.route('/join',methods=['POST','GET'])
def join():
    if 'email' in session:
        return session['email'] + '님이 로그인 중입니다.'+"<form method='post' action='/'><input type='submit' value='메인으로 가기'></form>"+"<form method='post' action='/logout'><input type='submit' value='logout'></form>"
    
    else:
        return render_template('join.html')

@app.route('/join_check',methods=['POST','GET'])
def join_check():
    if not request.values['name'] or not request.values['email'] or not request.values['passwd'] or not request.values['passwd1']:
        flash('회원가입 양식을 다시 한번 확인하여주세요.')
        return redirect(url_for('index'))
    
    else:
        #    python md5 사용법 md5.md5(mystring).hexdigest()
        passwd = md5.md5(request.values['passwd']).hexdigest()
        passwd1 = md5.md5(request.values['passwd1']).hexdigest()
        
        if passwd != passwd1:
            flash('패스워드와 확인 패스워드가 일치하지 않습니다.')
            return redirect(url_for('join'))
        
        else:
            email = request.values['email'] # 폼에서 받은 email
        
            confirm_email = User1.query.filter_by(email = email).first()
        
            if confirm_email: # 이미 회원가입 되어 있는 경우
                flash('이미 존재하는 이메일입니다.')
                return redirect(url_for('join'))
        
            else: # 회원가입이 되어 있는 email이 아닌 경우
                email = request.values['email']
                name = request.values['name']
                              
                new_account = User1(email,name,passwd)
                
                db.session.add(new_account)
                db.session.commit()
                
                flash('회원가입이 완료 되었습니다.')
                return redirect(url_for('index'))
    
if __name__ == '__main__':
    app.run()